﻿using System;
using static System.Console;

namespace Singleton
{
  public sealed class Singleton
  {
    static int instanceCounter = 0;
    private static readonly Lazy<Singleton> singleInstance = new Lazy<Singleton>(()=>new Singleton()); //private static Singleton singleInstance = null;
    private Singleton()
    {
      instanceCounter++;
      WriteLine("Instances created " + instanceCounter );
    }

    public static Singleton SingleInstance
    {
      get
      {
        return singleInstance.Value;
      }
    }
    public void LogMessage(string message)
    {
      WriteLine("Message " + message);
    }
  }
}
