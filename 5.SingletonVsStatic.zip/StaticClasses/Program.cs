﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace StaticClasses
{
  class Program
  {
    static void Main(string[] args)
    {
      double radiusOfCircle = 10.8;
      double lengthOfRectangle = 5.5;
      double widthOfRectangle = 2.3;
      double sideOfSquare = 4.0;
      double heightOfTriangle = 9.0;
      double baseOfTriangle = 5.0;

      WriteLine("Area of Rectangle with length {0} and width {1} is {2}", lengthOfRectangle, widthOfRectangle, Areas.AreaOfRectangle(lengthOfRectangle, widthOfRectangle));
      WriteLine("Area of Square with side {0} is {1}", sideOfSquare, Areas.AreaOfSquare(sideOfSquare));
      WriteLine("Area of Circle with radius {0} is {1}", radiusOfCircle, Areas.AreaOfCircle(radiusOfCircle));
      WriteLine("Area of Triangle with height {0} and base {1} is {2}", heightOfTriangle, baseOfTriangle, Areas.AreaOfTraingle(heightOfTriangle, baseOfTriangle));
      ReadLine();

    }
  }
}
