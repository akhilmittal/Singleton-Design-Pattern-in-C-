﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Math;

namespace StaticClasses
{
  public static class Areas
  {
    /// <summary>
    /// Area of Circle is πr2.
    /// value of pi is 3.14159 and r is the radius of the circle.
    /// </summary>
    /// <returns></returns>
    public static double AreaOfCircle(double radius)
    {
      return PI * (radius * radius);
    }

    /// <summary>
    /// Area of Square is side2.
    /// Side * Side
    /// </summary>
    /// <returns></returns>
    public static double AreaOfSquare(double side)
    {
      return side * side;
    }

    /// <summary>
    /// Area of Rectangle is L*W.
    /// L is the length of one side and W is the width of one side
    /// </summary>
    /// <returns></returns>
    public static double AreaOfRectangle(double length, double width)
    {
      return length * width;
    }

    /// <summary>
    /// Area of Traingle is b*h/2.
    /// b is base and h is height of traingle
    /// </summary>
    /// <returns></returns>
    public static double AreaOfTraingle(double baseOfTraingle, double heightOfTraingle)
    {
      return (baseOfTraingle * heightOfTraingle)/2;
    }
  }
}
